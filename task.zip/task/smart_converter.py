import os
import requests
import json
import base64
import docx
from docx import Document
from docx.shared import Inches
import re
import subprocess
import glob
import logging

# Setup logging
logging.basicConfig(level=logging.INFO, format='%(asctime)s - %(levelname)s - %(message)s')

API_KEY = ""

def get_gemini_response(image_path):
    """
    Sends image to Gemini API and requests text transcription + Python code for diagrams.
    """
    try:
        with open(image_path, "rb") as f:
            image_data = f.read()
            
        base64_image = base64.b64encode(image_data).decode('utf-8')
        
        # Dynamic model discovery
        model_name = "gemini-1.5-flash-latest" # Fallback
        
        # Quick check for valid models
        try:
             models_url = f"https://generativelanguage.googleapis.com/v1beta/models?key={API_KEY}"
             m_resp = requests.get(models_url).json()
             for m in m_resp.get('models', []):
                 if 'generateContent' in m.get('supportedGenerationMethods', []):
                     if 'flash' in m['name']: 
                         model_name = m['name'].replace("models/", "")
                         break
                     if 'pro' in m['name']:
                         model_name = m['name'].replace("models/", "")
        except:
            pass

        logging.info(f"Using model: {model_name}")
        url = f"https://generativelanguage.googleapis.com/v1beta/models/{model_name}:generateContent?key={API_KEY}"
        headers = {'Content-Type': 'application/json'}
        
        prompt_text = """
        You are an expert OCR and technical diagram transcription system.
        
        TASK:
        1. Transcribe all text from the image accurately.
        2. If you see any diagrams, charts, graphs, or technical illustrations:
           - DO NOT describe them in text.
           - Instead, write a Python script using `matplotlib` to RECREATE that diagram exactly.
           - Place the Python code inside these specific tags: [[DIAGRAM_CODE_START]] ... [[DIAGRAM_CODE_END]]
           - The Python code MUST save the figure to a file named 'generated_diagram.png' and close the plot.
           - Example code structure:
             ```python
             import matplotlib.pyplot as plt
             fig, ax = plt.subplots()
             # ... drawing commands ...
             plt.savefig('generated_diagram.png')
             plt.close()
             ```
           - Use ONLY `matplotlib` and `numpy`.
        
        FORMATTING:
        - Output the text normally.
        - Insert the diagram code blocks in the natural flow where the diagrams appear in the document.
        """
        
        payload = {
            "contents": [{
                "parts": [
                    {"text": prompt_text},
                    {
                        "inline_data": {
                            "mime_type": "image/jpeg", 
                            "data": base64_image
                        }
                    }
                ]
            }]
        }
        
        response = requests.post(url, headers=headers, data=json.dumps(payload))
        if response.status_code != 200:
            logging.error(f"API Error: {response.text}")
            return None
            
        result = response.json()
        if 'candidates' in result and result['candidates']:
            return result['candidates'][0]['content']['parts'][0]['text']
        else:
            logging.warning("No candidates returned.")
            return None
            
    except Exception as e:
        logging.error(f"Failed to call API: {e}")
        return None

def execute_diagram_code(code, unique_id):
    """
    Saves and runs the generated python code to produce an image.
    Returns path to the generated image or None.
    """
    code_dir = "e:/PPIT/diagram_code"
    os.makedirs(code_dir, exist_ok=True)
    
    script_path = os.path.join(code_dir, f"diag_{unique_id}.py")
    image_output_name = f"diag_img_{unique_id}.png"
    # We need to modify the code to save to a specific filename we control, or rename 'generated_diagram.png'
    # Actually, simplest is to let it save to 'generated_diagram.png' then we rename it.
    # But parallel execution? For now serial is fine.
    
    # Better: Inspect code and force filename? 
    # Or just replace 'generated_diagram.png' in the string with our absolute path.
    valid_output_path = os.path.join(code_dir, image_output_name)
    escaped_path = valid_output_path.replace('\\', '/')
    
    code = code.replace("generated_diagram.png", escaped_path)
    # Fix common Matplotlib LaTeX errors
    code = code.replace(r"\implies", r"\Rightarrow")
    
    with open(script_path, "w", encoding='utf-8') as f:
        f.write(code)
        
    try:
        logging.info(f"Executing diagram script: {script_path}")
        result = subprocess.run(["python", script_path], capture_output=True, text=True, timeout=30)
        if result.returncode == 0 and os.path.exists(valid_output_path):
            logging.info("Diagram generated successfully.")
            return valid_output_path
        else:
            logging.error(f"Diagram generation failed. Stderr: {result.stderr}")
            return None
    except Exception as e:
        logging.error(f"Error running script: {e}")
        return None

def main():
    image_dir = "e:/PPIT"
    output_doc_path = os.path.join(image_dir, "Converted_Smart_Output.docx")
    
    doc = Document()
    
    files = [f for f in os.listdir(image_dir) if f.lower().endswith(('.jpg', '.jpeg', '.png'))]
    files.sort()
    
def process_single_image_to_doc(image_path, doc):
    """
    Processes a single image:
    1. Sends to Gemini for text + diagram code
    2. Executes diagram code
    3. Adds content to the provided docx Document object
    """
    filename = os.path.basename(image_path)
    logging.info(f"Processing {filename}...")
    
    response_text = get_gemini_response(image_path)
    if not response_text:
        return False
        
    doc.add_heading(f"Source: {filename}", level=1)
    
    # Parse text and code blocks
    # Split by regex
    parts = re.split(r'\[\[DIAGRAM_CODE_START\]\](.*?)\[\[DIAGRAM_CODE_END\]\]', response_text, flags=re.DOTALL)
    
    for i, part in enumerate(parts):
        if i % 2 == 0:
            # This is TEXT
            if part.strip():
                doc.add_paragraph(part.strip())
        else:
            # This is CODE (odd index)
            code_block = part.strip()
            # Remove markdown fences if present
            code_block = code_block.replace("```python", "").replace("```", "")
            
            unique_id = f"{filename}_{i}"
            # Ensure unique ID is file-system safe
            unique_id = "".join([c for c in unique_id if c.isalpha() or c.isdigit() or c=='_']).rstrip()
            
            img_path = execute_diagram_code(code_block, unique_id)
            
            if img_path:
                try:
                    doc.add_picture(img_path, width=Inches(5))
                except Exception as e:
                    logging.error(f"Could not add image {img_path}: {e}")
                    doc.add_paragraph("[Diagram Generation Failed - See Logs]")
            else:
                doc.add_paragraph("[Diagram Generation Failed]")
    
    doc.add_page_break()
    return True

def main():
    image_dir = "e:/PPIT"
    output_doc_path = os.path.join(image_dir, "Converted_Smart_Output.docx")
    
    doc = Document()
    
    files = [f for f in os.listdir(image_dir) if f.lower().endswith(('.jpg', '.jpeg', '.png'))]
    files.sort()
    
    for filename in files:
        if "WhatsApp" not in filename: continue # Filter for target images if needed
        file_path = os.path.join(image_dir, filename)
        process_single_image_to_doc(file_path, doc)
        doc.save(output_doc_path) # Incremental save
        
    logging.info(f"Done. Saved to {output_doc_path}")

if __name__ == "__main__":
    main()
