
import requests
import json
import base64
from docx import Document
from docx.shared import Inches

import os

# --- CONFIGURATION ---
# 🔑 PASTE YOUR API KEY HERE
API_KEY = "AIzaSyCAu8GFVsnTLFR5bN9kzCB4_g5L4L1t1U4"
# ---------------------

def master_converter():
    if API_KEY == "PASTE_YOUR_API_KEY_HERE":
        print("❌ STOP: You must paste your API Key in the code above first!")
        return

    print("🔍 DIAGNOSTIC: Checking your API Key permissions...")
    
    # 1. Get the exact list of models your key can see
    # We check both the Beta and Stable endpoints
    endpoints = [
        "https://generativelanguage.googleapis.com/v1beta/models",
        "https://generativelanguage.googleapis.com/v1/models"
    ]
    
    valid_model_name = None
    
    for endpoint in endpoints:
        try:
            response = requests.get(f"{endpoint}?key={API_KEY}")
            if response.status_code == 200:
                data = response.json()
                print(f"   ✅ Connected to {endpoint}")
                
                # Filter for models that support generating content
                for model in data.get('models', []):
                    name = model['name'] # This comes as "models/gemini-..."
                    methods = model.get('supportedGenerationMethods', [])
                    
                    if 'generateContent' in methods:
                        # Prioritize Vision models (Flash/Pro)
                        if 'flash' in name or 'pro' in name or 'vision' in name:
                            valid_model_name = name
                            print(f"   🎯 Found compatible model: {valid_model_name}")
                            break
                if valid_model_name:
                    break
        except Exception as e:
            print(f"   ⚠️ Connection check failed for {endpoint}")

    if not valid_model_name:
        print("\n❌ CRITICAL ERROR: Your API Key is valid, but it has no access to any Generative Models.")
        print("👉 SOLUTION: Go to https://aistudio.google.com/app/apikey and create a NEW key in a new project.")
        return

    print(f"\n🚀 STARTING CONVERSION USING: {valid_model_name}")
    
    # Local scanning instead of files.upload()
    image_dir = "e:/PPIT"
    print(f"Scanning directory: {image_dir}")
    
    valid_extensions = {'.jpg', '.jpeg', '.png'}
    # Find all images
    files_list = [f for f in os.listdir(image_dir) if os.path.splitext(f.lower())[1] in valid_extensions]
    
    if not files_list:
        print("No images found in folder.")
        return

    # Mock 'uploaded' dict logic to map filename -> bytes
    uploaded = {}
    for fname in files_list:
        if "WhatsApp" in fname: # Optional filter based on your files
             with open(os.path.join(image_dir, fname), "rb") as f:
                 uploaded[fname] = f.read()
    
    if not uploaded:
         print("No matching images found (checked for WhatsApp in name). Processing all images...")
         for fname in files_list:
             with open(os.path.join(image_dir, fname), "rb") as f:
                 uploaded[fname] = f.read()

    for filename in uploaded.keys():
        print(f"\nProcessing {filename}...")
        
        image_data = uploaded[filename]
        base64_image = base64.b64encode(image_data).decode('utf-8')
        
        # 2. Dynamic URL Construction (Prevents the 404 error)
        # Note: valid_model_name ALREADY contains "models/" (e.g., "models/gemini-1.5-flash")
        # So we do NOT add it to the URL.
        # Handle cases where model_name might or might not have 'models/' prefix depending on discovery
        if not valid_model_name.startswith("models/"):
             model_id = f"models/{valid_model_name}"
        else:
             model_id = valid_model_name
             
        url = f"https://generativelanguage.googleapis.com/v1beta/{model_id}:generateContent?key={API_KEY}"
        
        headers = {'Content-Type': 'application/json'}
        
        prompt_text = """
        You are a smart transcriber. 
        Task: Convert these handwritten Chemistry notes into a clean, structured text format.
        
        CRITICAL INSTRUCTION FOR DIAGRAMS:
        - Do NOT try to describe the diagrams (graphs, boxes, drawings) in text.
        - Instead, when you reach a point in the notes where a diagram, graph, or box appears, write exactly this tag on a new line: [[DIAGRAM_PLACEHOLDER]]
        - Continue the text transcription after the tag.
        
        formatting:
        - Use clean headings.
        - Fix typos.
        - Write math formulas in plain text representation (e.g., "x/m = kP^(1/n)").
        """
        
        payload = {
            "contents": [{
                "parts": [
                    {"text": prompt_text},
                    {
                        "inline_data": {
                            "mime_type": "image/jpeg", 
                            "data": base64_image
                        }
                    }
                ]
            }]
        }

        try:
            response = requests.post(url, headers=headers, data=json.dumps(payload))
            
            if response.status_code != 200:
                print(f"⚠️ API Error {response.status_code}: {response.text}")
                continue
                
            result_json = response.json()
            if 'candidates' in result_json and result_json['candidates']:
                full_text = result_json['candidates'][0]['content']['parts'][0]['text']
            else:
                print("⚠️ AI returned no text. Image might be blocked.")
                print(result_json)
                continue
            
            print("📝 Generating Word Document...")
            doc = Document()
            doc.add_heading(f'Notes: {filename}', 0)

            content_blocks = full_text.split('[[DIAGRAM_PLACEHOLDER]]')

            for i, block in enumerate(content_blocks):
                lines = block.strip().split('\n')
                for line in lines:
                    if line.strip():
                        doc.add_paragraph(line)
                
                if i < len(content_blocks) - 1:
                    p = doc.add_paragraph()
                    run = p.add_run()
                    run.add_break()
                    run.add_text("[DIAGRAM PLACEHOLDER - Check 'smart_converter' for auto-generation]")
                    run.add_break()
                    
                    # Original logic just pasted the whole image which requires manual cropping
                    # We keep this behavior for app.py as likely intended by original script
                    temp_img_path = f"temp_{filename}.jpg"
                    with open(temp_img_path, "wb") as f:
                        f.write(image_data)
                    
                    doc.add_picture(temp_img_path, width=Inches(5.0))
                    
                    if os.path.exists(temp_img_path):
                        os.remove(temp_img_path) 
                    
                    run.add_break()
                    doc.add_paragraph("----------------------------------------")

            output_filename = os.path.splitext(filename)[0] + "_Final.docx"
            doc.save(os.path.join(image_dir, output_filename))
            
            print(f"✅ Success! Saved to {output_filename}")
            # files.download removed
            
        except Exception as e:
            print(f"⚠️ Error: {e}")

if __name__ == "__main__":
    master_converter()